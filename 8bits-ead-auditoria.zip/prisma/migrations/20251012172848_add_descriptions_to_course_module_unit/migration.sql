-- AlterTable
ALTER TABLE "Course" ADD COLUMN "description" TEXT;

-- AlterTable
ALTER TABLE "Module" ADD COLUMN "description" TEXT;

-- AlterTable
ALTER TABLE "Unit" ADD COLUMN "description" TEXT;
