-- AlterTable
ALTER TABLE "Module" ADD COLUMN "posterUrl" TEXT;

-- AlterTable
ALTER TABLE "Unit" ADD COLUMN "posterUrl" TEXT;
