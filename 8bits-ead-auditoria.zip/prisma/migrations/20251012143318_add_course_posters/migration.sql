-- AlterTable
ALTER TABLE "Course" ADD COLUMN "posterNarrowUrl" TEXT;
ALTER TABLE "Course" ADD COLUMN "posterWideUrl" TEXT;
